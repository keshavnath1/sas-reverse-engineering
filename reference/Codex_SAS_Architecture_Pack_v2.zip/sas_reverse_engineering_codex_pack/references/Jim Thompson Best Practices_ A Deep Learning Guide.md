# Jim Thompson Best Practices: A Deep Learning Guide

**Author: Manus AI**

Jim’s central principle is **successfully verified work with appropriate model capability, focused context, deliberate planning, bounded execution, and proportionate checks—not simply fewer tokens.** The point is not to make every interaction tiny or to make the assistant work alone. It is to get the right result with evidence, while avoiding needless wandering, retries, and rework.

This guide teaches that principle through one **clearly illustrative** Python project. Imagine `scenario_calc.py`, a module that projects cash flow for **base**, **upside**, and **downside** scenarios. It is a learning example only. It does not describe your team’s codebase, identify a defect, or explain any reported shared-quota pressure.

Some guidance here is portable across AI coding tools: clarify the task, bring relevant evidence, test meaningful changes, and retain human judgment. Other behaviors are **product controls**, such as which model choices, agent abilities, reporting screens, or automatic actions are available. Those depend on the installed production Copilot version, plan, policy, settings, and surface. Verify them locally rather than assuming a prompt can turn them on. A prompt is a **behavioral guardrail**—a clear instruction that helps steer work—not necessarily hard runtime budget enforcement.

## 1. Start with model selection, not “cheap” or “strong” by default

A model is the AI system doing the reasoning. Different models trade off speed, cost, and capability. Jim Thompson’s practical recommendation is to start with the **least expensive and fastest model likely to meet the quality bar**, then move up only when the task’s complexity or the evidence from the work justifies it. That is very different from “always use the least expensive model.” [1]

Use the task, not habit, to choose a starting point. A narrow edit with a supplied rule and a focused test is often a routine task. A change that crosses several modules, contains ambiguous business rules, or involves consequential design trade-offs needs more reasoning and may warrant a balanced or stronger model from the start. For everyday Copilot work, Jim recommends Auto—Balance, with greater capability for difficult tasks; GitHub describes Auto selection as routing based on task complexity and model availability, which can be affected by plan and policy. [1] [2]

In the illustrative module, suppose the request is: “Use the provided 3% growth rate in the downside calculation.” If the function and expected arithmetic are clear, start with a fast, economical model. If the request instead says, “Make downside growth interact correctly with revenue, cost, and cash-flow conventions,” first determine which conventions and dependencies apply. A balanced model may be appropriate because the change is no longer a single, specified edit.

Do not escalate merely because the first response feels uncertain. First ask: **Is the requested outcome clear? Does the assistant have the relevant function, assumptions, and test?** Missing information can defeat a strong model too. Escalate when dependencies stay unclear after targeted inspection, failures cannot be explained, or the remaining decision has meaningful risk. Then validate the result. A powerful model’s confident answer—or agreement between two models—is not evidence by itself.

Try this prompt:

> In this illustrative `scenario_calc.py` module, update only the supplied function to apply the stated downside revenue-growth assumption. First state your understanding and any missing assumption that would change the result. Keep the edit focused, add or update an expected-result test, and report the test outcome. Do not modify unrelated code.

The useful features are the specified scope, request for uncertainty, and expected check. The model selection does not replace them. Think in **total effort**: a very capable model on a trivial request may be needless, but a weak approach that produces several failed attempts can cost more time and usage than a suitable model that succeeds once.

## 2. Give the assistant focused context, progressively

The **context window** is the working material an AI model can consider for a request. It can include your prompt, earlier conversation, standing instructions, referenced files, and tool results. It is not a reliable permanent project archive. In VS Code agent experiences, explicitly added context also takes up window space; compaction can summarize earlier conversation, but may omit details. [3]

Good context management is not “use as few tokens as possible.” It is “supply what is needed for this decision, and add more only when there is a stated reason.” Jim’s guide recommends progressive loading: begin with the task, find the relevant files, and inspect more as the work demands. It also favors short durable instructions and concise checkpoints at meaningful milestones. [1]

For our illustrative downside-case review, begin with `scenario_calc.py`, the documented revenue and cost assumptions relevant to downside behavior, and directly related tests. State the expected behavior. If the calculation refers to a shared input definition and that is the unanswered question, bring in that definition next. Loading an entire repository, every old chat message, or a huge unrelated log “just in case” gives the assistant more material to sift through and can lead it toward stale or irrelevant details. But omitting a key assumption or a test just to shrink the request can make the work less accurate.

A context-aware review prompt is:

> Illustrative task: review the downside-case calculation in `scenario_calc.py` against the documented revenue and cost assumptions. First inspect this module and its directly relevant tests. Do not edit yet. If another file is needed, name the precise question it will answer. Report evidence, uncertainty, and one focused test to run.

For related work, keep stable instructions and verified facts available. At a real milestone, create a short **checkpoint**: decisions made, files changed, tests run and results, and open questions. A checkpoint preserves useful facts when a later session needs to continue. Do **not** reset context for every small prompt; do **not** compact before every request. Start fresh for unrelated work, and compact or summarize when history has become irrelevant or unwieldy, recognizing that a summary may lose details.

Bad instructions create waste here. “Read the repo, find every issue, redesign the scenario system, and make it robust” is broad, untestable, and invites exploration that the requester may not need. The assistant may inspect irrelevant material, make unrelated proposals, and require clarification or reversals. That mechanism can waste effort and model interactions, but it is **not** evidence about the cause of any particular team’s usage or quota issue.

## 3. Plan in proportion to the task

Planning means agreeing on success, learning enough from the actual repository to choose a safe route, and breaking substantial work into reviewable steps. It does not mean demanding a long plan before a one-line spelling correction. Jim recommends scaling planning to complexity and risk: informal for trivial work, brief for a small change, and phased with verification and developer approval gates for consequential or uncertain work. The pattern is plan, execute with feedback, validate, then advance. [1]

For the illustrative scenario module, a sound plan starts by inspecting repository instructions, existing calculation code, tests, and conventions. Separate **verified facts** (“the current downside function accepts these inputs”) from **assumptions** (“negative growth should be allowed”). Then define observable acceptance criteria. For example: given agreed inputs, each scenario returns agreed projected cash flow; invalid inputs are handled as specified; no unrelated scenario changes.

A useful phased plan might be: (1) confirm inputs, outputs, and behavior; (2) make the focused implementation; (3) verify ordinary, boundary, and integration behavior. The developer reviews the plan before editing and reviews the evidence at phase boundaries. If inspection changes what is known, revise the plan rather than blindly following the old one.

> Before editing, inspect the relevant repository instructions, Python calculation code, and tests. Separate verified facts from assumptions, ask about ambiguity that changes expected results, then propose a short phased plan with acceptance criteria and a check for each phase. Stay within scope and wait for my review.

Automated tests are important evidence, but they are not human approval of the business assumption, scope, or risk. Common failures are planning from guesses, accepting vague “done” criteria, overplanning a small task, expanding scope, and continuing after the plan is no longer current.

## 4. Use open loops to learn and closed loops to verify

An **open loop** asks the assistant to explain, explore, or draft, without automatically checking the outcome. It is appropriate when you want ideas: “How should a growth assumption affect projected cash flow?” A **closed loop** adds explicit completion criteria and feedback: define expected behavior, make the change, run a relevant check, inspect the result, and make a justified correction if needed. Jim recommends open loops for exploration and closed loops where implementation needs confidence. [1]

Our scenario work can use both. First, ask for a sketch of how base, upside, and downside assumptions should be represented. That is open-loop learning. Before merging an implementation, state a few input/output examples, implement only that behavior, and run targeted unit tests. If a test fails, inspect why. Correct the calculation or test only when the evidence supports doing so, then rerun.

> Implement the stated behavior in this illustrative scenario module: [give inputs and expected outputs]. Run the relevant unit tests. If one fails, explain the failure, make one focused correction, and rerun. Do not weaken tests or change the expected behavior just to get a pass. Stop after two correction attempts and report unresolved issues.

The two-attempt limit above is an illustrative starting rule; Jim’s sample prompt uses three correction attempts. Choose a bounded limit appropriate to the task. It is a stopping rule, not a promise that a set number of attempts will solve anything. **Retries still cost** time and model usage. When new attempts do not produce new evidence or progress, pause, narrow the question, obtain missing requirements, inspect the dependency, or use appropriate human review. Do not keep asking for another rewrite. [1]

Conversely, do not avoid verification just to save tokens. A fluent response is not proof; a passing test is stronger evidence for the cases it covers, but not proof that every financial assumption or edge case is correct. Review the diff and assumptions proportionately. Some Copilot agent experiences can edit code and run tests or linters, but available capabilities vary by product surface and settings. [4] GitHub also documents workflows for generating and executing tests. [5]

## 5. Add subagents selectively, then integrate their evidence

A **subagent** is a separate delegated AI worker with a bounded responsibility. Its separate context can make a large investigation easier to manage or provide an independent review. Jim’s principle is not “maximize parallelism.” It is to delegate **bounded, independent** work where the value is worth coordination, while the primary assistant remains responsible for integration and validation. [1]

For example, one read-only subagent could inspect whether scenario assumptions are applied consistently in `scenario_calc.py`; another could examine relevant tests for missing boundary cases. Give each a distinct question and require evidence—file locations, lines, a concrete failure scenario, or an explicit “no supported issue found.” The main assistant compares reports, resolves conflict, makes any coordinated change, and runs the final checks.

> Inspect this illustrative scenario-calculation module for inconsistent application of scenario assumptions. Do not edit. Cite relevant files and lines, explain one concrete failure scenario if supported, and separate verified findings from questions. Be concise.

Do not delegate a simple variable rename or tightly sequential work merely because agents are available. Each subagent makes its own model interactions. Parallel workers can therefore **increase total consumption**, and overlapping tasks can duplicate work and complicate integration. Separate context may reduce clutter in the main conversation; it does not guarantee lower total usage. GitHub similarly frames delegation as best for independent work with clear boundaries, not inherently sequential tasks. [6]

## 6. Understand caching and measure the right thing

**Prompt caching** may reuse an eligible unchanged part of prior input, often a prefix, rather than processing it again. It can reduce repeated processing and latency, but it neither expands the context window nor makes an answer accurate. Jim’s guidance is to keep useful stable context steady and manage sessions for task quality, rather than chasing the highest cache percentage. [1] [7]

For related edits to our scenario module, stable conventions and the unchanged module context may be useful. Keep them stable when they remain relevant; do not retain stale history merely to seek cache reuse. If you switch models mid-session, the new model cannot reuse the prior model’s cache, according to GitHub; a suitable consistent model for related work may preserve reuse, but a cache hit is not guaranteed. [7] Start a new session for unrelated work. Summarize or reduce old material when it has become irrelevant, but not reflexively before every request.

The words used in usage discussions are easy to mix up:

- **Context-window occupancy** is the amount of material present in the model’s working context at one point in time. Caching does not remove that occupancy.

- **Cumulative token usage** is usage added up across requests, a session, or a period. It grows through retries and through additional agent interactions.

- **Enterprise billing or quota units** are the provider’s accounting measure. They are not safely inferred from a context snapshot or a raw local token count.

**Cached input is a subset of input tokens**, not a second extra amount to add on top of input. Output tokens are generated by the model. Do not confuse any of those fields with enterprise billable credits. For shared-quota questions, use the organization’s **authoritative admin report**, not local diagnostics. The repository’s local counters only analyze available Codex or Copilot logs; missing logs or a displayed zero do not prove zero usage, and its Copilot counter does not establish inline-completion coverage. You can use the counters on your own authorized local logs to investigate recorded usage, subject to your organization’s policies; that does not establish the organization’s remaining quota. [8] [9]

There is a real gap to respect: this guide cannot tell you which quota fields, reporting coverage, cache behavior, model controls, or agent actions exist in a particular installed production Copilot environment. Confirm those through authorized product and admin documentation for that environment. Do not invent a control or translate a local diagnostic into a billing conclusion.

## A worked start-to-finish walkthrough

A developer asks: “Add a downside revenue-growth assumption to `scenario_calc.py`, preserve existing base and upside behavior, and prove the scenarios still work.”

1. **Clarify and choose a starting capability.** Ask for the intended inputs, handling of invalid values, and expected numbers or rules. If this is a specified local edit with a known test, use a routine capable model. If it requires reconciling several accounting conventions, begin with a balanced model. This choice is provisional: evidence can justify escalation.

1. **Load the smallest sufficient first context.** Provide the request, `scenario_calc.py`, directly related tests, and relevant assumption documentation. Do not load the whole repository. If the function references a shared type, add that file only because it answers a known question.

1. **Plan before the substantive edit.** Request verified facts, assumptions, and a short three-phase plan. Review it. Agree on examples such as a starting cash flow, a downside growth rate, expected projected value, and invalid-input behavior.

1. **Explore, then close the loop.** If the formula is uncertain, ask for an explanation first. Then request the focused change and targeted tests. Inspect failures; do not let the assistant weaken a test to manufacture a pass. Stop after bounded attempts if evidence is not improving.

1. **Delegate only if there is a real independent question.** A read-only test-coverage review can run separately while the primary thread examines formula consistency. Do not split the actual implementation across agents until file ownership and integration are clear.

1. **Finish with evidence and a checkpoint.** Review changed files, test results, remaining uncertainty, and the diff. Record a compact checkpoint for related follow-up. The outcome is not “we used few tokens”; it is a focused, reviewed calculation change with appropriate evidence.

Notice how the practices reinforce one another. Clear requirements make model choice easier. Focused context makes planning more accurate. A plan creates testable expectations. Tests make escalation evidence-based. Subagents contribute facts rather than noise. Cache awareness supports stable related work without becoming the goal.

## Brief learning exercise

**Exercise:** A request says, “Make `scenario_calc.py` better and keep usage low.” Rewrite it into a safe first request, and name the first context you would include.

**Sample answer:** “In this illustrative project, review the downside calculation in `scenario_calc.py` against the documented revenue-growth rule. Do not edit yet. Inspect this module and its directly relevant tests, identify verified behavior and unanswered questions, and propose one focused acceptance test. If another file is needed, explain the question it answers.” I would include the request, `scenario_calc.py`, the directly relevant test file, and the documented growth rule—not the full repository. I would choose a routine capable model unless the initial review shows interacting assumptions or unresolved ambiguity. This prompt reduces aimless exploration without claiming to enforce a hard budget or skipping the verification needed for a meaningful change.

## References

[1]: https://github.com/jimthompson5802/coding-assistant-practices "Jim Thompson’s Coding Assistant Practices"

[2]: https://docs.github.com/en/copilot/concepts/models/auto-model-selection "GitHub Copilot Automatic Model Selection"

[3]: https://code.visualstudio.com/docs/agents/concepts/context "VS Code: Understand Context in AI Agents"

[4]: https://docs.github.com/copilot/concepts/agents/coding-agent/about-coding-agent "GitHub Copilot Coding Agent Overview"

[5]: https://docs.github.com/en/copilot/tutorials/write-tests "GitHub Copilot: Writing Tests"

[6]: https://docs.github.com/en/copilot/concepts/agent-capabilities/choosing-and-delegating-agent-work/delegating-and-parallelizing-work-with-agents "GitHub Copilot: Delegating and Parallelizing Work with Agents"

[7]: https://docs.github.com/en/copilot/tutorials/optimize-ai-usage "GitHub Copilot: Optimize AI Usage"

[8]: https://github.com/jimthompson5802/coding-assistant-practices/blob/main/README.md "Coding Assistant Practices Repository README"

[9]: https://github.com/jimthompson5802/coding-assistant-practices/blob/main/codex-cache-reporting.md "Local Token Reporting Notes"

