# Early discovery can reuse trace knowledge—but the handoff is not yet enforced

The current framework can reuse its trace extraction contract for early discovery without maintaining a second factual source. It cannot safely do so through prompt wording alone. The repository has reusable agent instructions, but no executable SAS extraction engine, no authorized `discover` stage, and no complete active-run validator for the trace-to-map handoff.

This audit examined a fresh public checkout of `feature/governed-learning-memory` at commit `bc754e0f1204a99020c864df2a5b25983005e09c` on 2026-11-04. It inspected extraction contracts, schemas, routing instructions, deterministic helpers, validators, evaluations, and CI. Repository files were unchanged and the final working tree was clean. No SAS, real migration, Copilot lifecycle, selected runtime, or desktop operation was executed.

## What we can actually reuse

The reference contract already describes source inventory, hashes, macro definitions and calls, includes, DATA-step inputs/outputs, PROC SQL joins, grouping and ordering, other procedures, library/configuration dependencies, and retained or order-sensitive state. It also requires log/LST counts, timings, warnings, source relationships, contradictions, and citations. These are exactly the observations an evidence-backed ADR needs. See `.github/skills/trace/references/sas-trace-contract.md:3–39`.[1]

The reusable machinery is **declarative knowledge executed by Copilot**, not a Python SAS parser. `scripts/intake.py` inventories file identities; it does not reconstruct SAS semantics. `scripts/project.py` exposes intake, status/start, template validation, tie-out, and learning validation, but no SAS parsing command. Trace explicitly prohibits an extractor-script fallback. Reuse should therefore begin with shared skill references and stronger artifact validation—not an unrequested replacement parser.[2] [3] [4]

Normal `trace` currently requires approved SPEC/ADRs and durable authorization. Calling it before architecture approval would violate its current contract, even though its factual extraction vocabulary is appropriate for discovery. The early phase needs an explicitly approved workflow/skill change.[2]

## Why Trace and Map overlap today

Trace is instructed to reconstruct produced/consumed datasets, macro/include relationships, and evidenced execution order. Map is separately instructed to build a dataset and column dependency graph, read cited SAS blocks, and decompose behavior. Its reference adds derived columns, sort/BY dependencies, reset/state boundaries, and implementation ownership.[1] [5] [6]

This is not simply duplicated code: some detail needed by map is not structurally guaranteed to exist in the trace. Removing map's dependency analysis without first strengthening the trace would lose coverage.

The safe responsibility split is:

- **Source capture:** extract factual operations, dataset/column dependencies, state, and evidence locators once under a shared source contract.
- **Trace verification/finalization:** verify the sealed source record, reconcile coverage and contradictions, and establish the canonical handoff.
- **Map:** reference those operation/edge IDs and assign target semantic, adapter, and test ownership under the selected ADR.

Map can reread source to challenge a claim. It must not silently replace a source edge. A new or contradictory finding returns to the source-evidence owner, creates a versioned revision, and invalidates affected downstream decisions. Target decomposition can split or fuse operations, but must retain links to the original source operation IDs.

## What the executable schemas enforce—and what they do not

### Trace: structure exists, but evidence content is largely unconstrained

The trace schema requires top-level sections. However, `scripts` and `logs` are arbitrary objects. File inventories contain path strings rather than required path/hash records. Produced and consumed datasets are flat name lists; there is no typed producer-to-consumer edge contract. Governance and citations are optional, with no enforced material-claim-to-source linkage. Stable operation IDs, citation bounds, and typed uncertainty records are not required.[7]

Consequently, satisfying this schema does not establish complete discovery, valid citations, or a correct dependency graph. The extraction instructions are substantially stricter than the schema.

### Map: canonical path is enforced, but hash and coverage relationships are not

The registry requires the correct canonical trace path and a nonempty hash string. It does not require SHA-256 syntax or recompute the referenced file hash. Dependencies, citations, and excerpt hashes are optional and loosely typed. Pattern IDs need not be unique or resolve to trace operations. Semantic owners can be empty strings. Coverage counts are independently nonnegative; they are not reconciled with the actual entries or the source behavior IDs.[8]

Some of these relationships belong in a deterministic validator, not JSON Schema. The issue is that the inspected branch does not supply the live trace/map validator that would enforce them.

### State: normal migration gates are mostly instruction-level

`orchestrate/SKILL.md` requires predecessor, artifact hash, human gate, single-skill, and atomic-update checks. `workflow.yaml` declares lifecycle order and control flags. These are useful operating rules. They are not a general executable migration transition engine.[9] [10]

The state schema excludes `discover`, permits unconstrained history objects, and does not require normal-stage artifact hashes or approvals. The narrowly structured `human_gate` field is for learning promotion, not PRD/ADR/trace approval. `project.start()` checks manifest existence and positive `file_count`, then writes interview-ready state without a manifest hash or atomic replace. `status()` selects the newest state globally by modification time rather than by an explicit module/run.[3] [11]

Thus, adding a discovery enum is necessary but insufficient. A schema-valid state does not establish that the authorized predecessor and human approvals actually occurred.

## Synthetic probes run against the actual schemas

The following probes used in-memory synthetic objects. They did not write canonical traces, registries, or active migration state.

1. **Empty trace template:** accepted by the schema. That is reasonable for an inert template, but inadequate for an active-run gate.
2. **Trace without governance and with a nonexistent source file, negative citation range, and fake hash:** accepted by the schema.
3. **Map with a fake trace hash, duplicate pattern IDs, empty semantic owner, dangling dependency IDs, and false coverage totals:** accepted by the schema.
4. **`generate / READY` state with empty history and no approvals or artifact hashes:** accepted by the schema.
5. **State whose stage is `discover`:** rejected because discovery is not in the permitted enum.

These are demonstrations of schema limits—not proof that a correctly following Copilot would approve those artifacts. A future active-run gate must reject such objects regardless of the agent's narrative verdict.

## What the existing test suite proves

The official smoke suite passed after installing the declared dependencies in a separate sandbox virtual environment. It ran 15 architecture tests, 13 generic tie-out tests, and 15 governed-learning tests. Environment: Python 3.12.3, PyYAML 6.0.3, jsonschema 4.26.0.[12]

Architecture validation checks skill/prompt structure, configuration values, canonical paths, selected template fields, and clean-template exclusions. It intentionally rejects active trace, registry, and run artifacts. It should remain a clean-public-template check, not be repurposed as the gate for a live migration.[13] [14]

The tie-out and learning suites exercise real deterministic mechanisms within their scopes. They are not merely documentation checks. Nevertheless, their passing results do not prove source-dependency extraction or Copilot stage execution. Trace/map pressure cases are documented expectations; the maintained smoke/CI path does not run a Copilot skill-evaluation harness.[4] [12] [15]

Tie-out validates approved comparison/provenance artifacts and declared input hashes. It does not establish that every source file has been included in the discovery record, nor does it automatically invalidate an ADR when previously sealed source observations change.[16]

## Recommended reuse design: one canonical source record, two authorized phases

For the first implementation, preserve these paths exactly:

```text
stage1_extraction/output/execution_trace.json
policy/policy_registry.yaml
artifacts/semantic_ir/<module>.json
artifacts/evidence/runs/<run-id>/attempts/<attempt-id>/
```

Use an explicitly authorized early `discover` phase that references the existing trace extraction contract. It captures the canonical trace as a sealed source-evidence candidate. It does **not** invoke normal `trace` as a hidden second specialist or claim approved business intent, architectural acceptance, parity, or performance.

After requirements and architecture approval, `trace` verifies the same source record and current inventory. If the observations remain complete and unchanged, reuse them; do not repeat extraction merely because the stage name is different. Record final verification/acceptance as control evidence bound to the exact content hash. A mutable `approval_status` label inside a file is not the trust anchor.

This requires an explicit rule for the existing embedded governance status: lifecycle authority must come from the checked control record, not agent-editable labels. If finalization changes the trace bytes, do not silently substitute the new hash. Preserve the prior snapshot, report the revision, and reverify/reapprove affected consumers against the new version. A stable factual-payload digest can distinguish an envelope-only change from changed observations, but does not itself authorize bypassing hash-bound gates.

Keep the canonical trace as the sole source-fact authority. A discovery summary, diagram, capability proposal, or optimization list is a derived view that cites trace operation/edge IDs. It must not be an independently editable competing factual graph. Historical sealed snapshots are audit history, not additional active sources of truth.

For a minimal pilot, permit only one active owner of the singleton canonical paths in a workspace. Reject a second concurrent module owner. Multi-module concurrency can later use isolated worktrees/run workspaces with the same relative canonical paths and explicit ownership; it must not rely on selecting the globally newest state file.

The proposed route is:

```text
Intake
→ Interview: confirm intent and authorize bounded discovery → human gate
→ Discover: shared trace contract; seal candidate source record → stop
→ Specify: reconcile source observations with intended requirements → human gate
→ Decide: draft permitted candidate designs → stop
→ Independent ADR evidence verification → stop
→ Comparison and exact human architecture selection → human gate
→ Trace: verify/reuse sealed source record; reopen changed dependencies → stop
→ Map: assign target ownership using source operation/edge IDs → stop
→ Model: semantic IR → conformance gate
→ Generate → Test → Validate
→ Target-runtime performance evidence → independent review → human release
```

These are proposed transitions, not capabilities currently available. The candidate-verification/comparison substates need registration; they must not be hidden inside one unrestricted `decide` invocation. Reuse the existing `orchestrate` controller and bounded recovery loop. Do not introduce a second controller.

## Smallest implementation scope justified by this audit

**First, formalize the shared source contract.** Add typed source identity, operation IDs, dataset and column nodes, producer/consumer and ordering edges, state/reset semantics, run-linked log evidence, and explicit unknowns. Use one definition across discovery and trace. Native schema validation should catch malformed instances; deterministic checks should resolve hashes, locators, graph references, and coverage. Semantic support still needs an independent source-aware review—valid links alone do not establish truth.

**Second, add active-run guards.** Bind explicit module/run identity, authorized source scope, complete fresh inventory, canonical artifact hashes, predecessor outcome, attributable approvals, and workspace ownership. Reconcile added, removed, and modified files as well as hashes of manifest files. Persist transitions atomically. A scope/source change must make affected evidence stale and require authorized revision, not silently admit new inputs.

**Third, narrow map after source coverage is sufficient.** Replace independent factual graph creation with reference-based source dependency consumption and target responsibility assignment. Generate coverage counters from ID reconciliation. Reject duplicate formula ownership and adapter reimplementation of business formulas.

**Fourth, keep template and live validation separate.** Continue the existing clean-template CI, and add active-run source/trace/map/state validation using synthetic fixtures. Keep public fixtures free of SAS business intake, records, real logs, generated module code, and accepted production evidence. Authoritative source fixtures and private Copilot evaluations can remain in a separately governed test workspace.

A reusable deterministic SAS parser may be evaluated later if needed. It is not necessary to claim that the current skill knowledge is reusable, and it is not already present. The first change should close the evidence/authority gap rather than silently replacing the agent-led migration workflow.

## Required tests before declaring discovery reuse implemented

A successful reuse test must show early discovery producing a sealed record and later trace reusing its exact operation/edge IDs and evidence hash without independent factual reconstruction. Map must consume those IDs and account for every required source behavior.

Negative tests must reject fabricated or stale hashes, invalid citation spans, omitted scoped files, changed includes, source/log run mismatches, dangling graph references, unsupported independence claims, duplicate owners, invented coverage, candidate evidence presented as accepted, and generation without the matching approved ADR/SPEC/IR chain. In particular, test a newly found dependency after ADR approval: it must reopen the affected gate, not be erased to fit the selected architecture.

State tests must prove that discovery requires prior human authorization, that a second workspace owner is blocked, that historical runs are selected explicitly, and that retries are append-only and bounded. Agent evaluations must separately demonstrate actual one-skill stops, no self-approval, no auto-map/model, and no raw-source mutation. Deterministic checks and recorded PASS files alone cannot substitute for those observed agent behaviors.

The practical conclusion is: **reuse the trace contract and its sealed evidence, not a second interpretation of SAS.** The audited branch has the necessary knowledge foundation. It still needs executable handoff, provenance, graph, and approval checks before early discovery can be called governed reuse.

## References

All links below are pinned to the audited commit; later branch changes may differ. Line ranges cited in the report are from that checkout.

[1]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/trace/references/sas-trace-contract.md "Trace source extraction reference contract"
[2]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/trace/SKILL.md "Trace skill authority and canonical artifact"
[3]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/scripts/project.py "Agent-owned project helper"
[4]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/trace/evals/cases.md "Trace pressure expectations"
[5]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/map/SKILL.md "Map skill dependency and ownership workflow"
[6]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/map/references/behavior-mapping-contract.md "Behavior mapping reference contract"
[7]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/trace/schemas/execution_trace.schema.json "Execution trace schema"
[8]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/map/schemas/policy_registry.schema.json "Policy registry schema"
[9]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/orchestrate/SKILL.md "Orchestrator instructions and gate checks"
[10]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/config/workflow.yaml "Lifecycle and canonical artifacts"
[11]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/contracts/run_state.schema.json "Durable run-state schema"
[12]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/scripts/smoke_test.py "Maintained framework smoke suite"
[13]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/scripts/validate_project.py "Clean-template project validation"
[14]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/scripts/validate_agent_architecture.py "Static agent architecture validation"
[15]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/workflows/template-validation.yml "Public-template continuous validation"
[16]: https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/scripts/run_tieout.py "Generic keyed tie-out runner and provenance checks"
