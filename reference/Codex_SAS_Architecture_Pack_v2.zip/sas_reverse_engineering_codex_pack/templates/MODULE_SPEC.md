# Module SPEC — <MODULE> — DRAFT

- Source record SHA-256: <hash>
- Related PRD requirement IDs: <IDs>
- Source operation/edge IDs: <IDs>

## Input/output schemas, keys and dataset lineage

## Exact observed SAS behavior and state/order/numeric rules

## Proposed intended behavior vs observed legacy quirks

## Invariants and explicit unknowns

## Planned deterministic unit, contract, keyed tie-out and runtime tests

## Dependency boundaries and integration contracts

## Human decisions required (no auto-approval)
