# ADR-<MODULE>-<RUNTIME> — Candidate (DRAFT)

- Module(s): <module IDs>
- Runtime: <Spark / Ray / Dask / Native / Hybrid>
- Source manifest SHA-256: <hash>
- Sealed source record SHA-256: <hash>
- Claim verification report: <path/hash>
- Benchmark execution: NOT_RUN
- Human selection: PENDING (downstream only)

## Context and business invariants

List SPEC IDs, observed behavior, source operation IDs, unknowns, data and training constraints.

## As-is HLD and LLD (Mermaid diagrams)

Show observed module sequence, operation graph, logs and timings; each node cites source operation ID.

## To-be HLD and LLD (Mermaid diagrams)

Show shared preparation, independent waves, partitioning, task/shuffle boundaries, joins, numerical semantics, resource and deployment choices.

## Computation difference ledger

| Source operation IDs | Proposed target operations | Preserved invariant | Evidence | Preconditions | Proof test |
|---|---|---|---|---|---|

## Parallelization blockers and counterexamples

Include DATA, STATE, ORDER, SIDE_EFFECT, UNKNOWN and RESOURCE constraints. No inference of independence from log order alone.

## Technology choice and alternatives

Compare Spark, Ray, Dask, native/NumPy and justified hybrid. State explicit exclusions.

## Measurable tradeoffs and benchmark contract

State baseline workload/hardware/versions/cache, predicted *hypotheses*, resource costs, repeated runs, correctness obligations and reversal triggers. No invented results.

## Cross-module growth and integration

Explain effect of 5 or 10 new modules, shared datasets, data transfer, deployment coupling and rollback.

## Claim ledger and independent evidence review

List claims, classifications, semantic verification status, source citations, unresolved assumptions, reviewer ID. Gate FAIL/BLOCKED for critical unsupported claims.

## Downstream approval and configuration

No selected runtime or human approval until Agent-mastery `decide` gate. Reference candidate runtime plan and shared draft tie-out contract.
