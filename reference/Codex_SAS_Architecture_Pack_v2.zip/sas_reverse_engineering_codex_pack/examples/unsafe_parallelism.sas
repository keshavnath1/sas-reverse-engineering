/* SYNTHETIC TRAINING FIXTURE ONLY. NOT A CUSTOMER WORKLOAD. */
data work.scenario_a;
  set work.loans;
  where segment = 'A';
run;

data work.scenario_b;
  set work.scenario_a;
  where risk_score > 600;
run;
