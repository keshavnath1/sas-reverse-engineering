All examples are synthetic, illustrative and **not executed**. They are future test fixtures and expected outcomes, not evidence of production correctness or performance.
