# SAS Reverse Engineering & Computation Architecture Planner — Codex Build Pack

**Status:** implementation proposal / repository-generation specification, **not** an implemented or benchmarked system. **Baseline:** `keshavnath1/Agent-mastery`, branch `feature/governed-learning-memory`; executable-contract audit pinned to `bc754e0f1204a99020c864df2a5b25983005e09c` (2026-11-04). Branch may have moved since that audit. **Prepared:** 2026-11-05.

## Start here

1. `docs/01_PRODUCT_AND_SCOPE.md` — authoritative requirements and non-goals.
2. `docs/02_ARCHITECTURE_AND_WORKFLOW.md` — **one normative workflow**, ownership, state, gates, and source record.
3. `docs/03_PARALLELISM_AND_ADRS.md` — eagle-eye execution analysis, blockers, Spark/Ray/Dask/native alternatives, HLD/LLD and measurements.
4. `docs/04_EVIDENCE_AND_EVALS.md` — semantic evidence, adversarial skill evals, status taxonomy, falsification and validation.
5. `docs/05_HANDOFF_AND_CONFIG.md` — exact downstream compatibility boundary, migration profile and tie-out draft rules.
6. `docs/06_CODEX_BUILD_PLAN.md` — implementation phases, acceptance tests, stop rules, Codex execution instructions.
7. `docs/07_REFERENCES_AND_PROVENANCE.md` — repository links, user-provided audit, REA research caveats, Jim Thompson guide.
8. `docs/08_DEMONSTRATION.md` — repeatable demonstration and success/failure criteria.
9. `docs/09_REA_CASE_STUDIES_AND_IMPLEMENTATION_LESSONS.md` — four case studies mapped to skills, evidence contracts, and adversarial tests.
10. `docs/10_ENGINEERING_PRACTICES_TO_EXECUTABLE_CONTROLS.md` — Jim Thompson guidance translated into verifiable agent practices.
11. `docs/11_REPOSITORY_AUDIT_TO_IMPLEMENTATION_TRACEABILITY.md` — specific Agent-mastery gaps, guardrails, and handoff requirements.
12. `docs/12_FINAL_ONE_SHOT_CHECKLIST.md` — coverage ledger and implementation acceptance checklist.
13. `templates/` and `contracts/` — proposed templates and example contracts; **not yet downstream-approved schemas**.
14. `verification/` — local packaging verification results and limitations.

## One-sentence mission

Recover what SAS actually computed, distinguish observed order from necessary dependency, discover safe computational and module parallelism, propose multiple evidence-backed HLD/LLD execution alternatives, draft PRD/SPEC/ADR/configuration packages, and hand them to **existing Agent-mastery** for independent reconciliation and human approval.

## Key boundaries

- **New repo:** read-only reverse engineering, evidence sealing, requirements/architecture *drafting*, independent claim checks, evaluation, handoff packaging. It does **not** generate production translation or self-approve requirements/architecture.
- **Existing repo:** governed approval, canonical trace verification, map, semantic IR, code generation, keyed SAS tie-out, selected-runtime benchmarks, independent review and release. No silent bypass of its `interview/specify/decide` gates.
- PRD != trace != map. PRD is intended business outcome; trace is observed source fact; map is target ownership under approved architecture.
- Source/log evidence can justify *candidate* parallelization, not guarantee speedup or prove independence from execution order alone.
- A valid schema/citation does not prove a claim is true. Independent semantic checks and negative tests are mandatory.

## Explicit scope decisions

- One sealed factual source graph per scoped run; derived diagrams and documents reference IDs/hashes, never maintain another authoritative graph.
- Whole-workload, cross-module, within-module, feature-engineering, partition, expression and training parallelism all assessed; no mandatory distributed runtime.
- Candidate ADRs may be Spark, Ray, Dask, native Python/NumPy, or hybrid; exclusions require evidence and justification. HLD and LLD are mandatory per viable candidate.
- Draft `migration_profile.yaml`, `tieout.yaml`, benchmark plan and per-candidate runtime plan. The human-approved selection is not set in the new repo.
- Preserve exact downstream canonical paths; import is a **new proposed adapter**, not a claim that existing `harvest/import` can approve this package.

## Packaging verification vs system verification

The included verification report tests file integrity, internal references, schemas/examples, and consistency markers. It does **not** claim SAS parsing accuracy, Copilot skill behavior, REA execution, or Spark/Ray/Dask performance. Those are implementation acceptance gates.
