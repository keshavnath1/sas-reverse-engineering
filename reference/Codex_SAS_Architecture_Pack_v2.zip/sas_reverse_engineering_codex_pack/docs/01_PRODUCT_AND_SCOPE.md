# 01 — Product Requirements and Boundaries (Normative)

## Problem and outcome

Legacy SAS workloads contain business semantics, implicit state, macros, multi-program dataset lineage, observed execution order, and sometimes unnecessary sequential work. Straight syntax translation reproduces inefficiency and can break semantics. Build a **separate upstream repository** to produce an evidence-backed migration design package for an existing governed downstream repository. Preserve approved behavior, not incidental SAS procedure or temporary dataset boundaries.

## Users and decisions

- Migration architect: inspect original and optimized execution HLD/LLD; challenge assumptions and select a candidate *later* in Agent-mastery.
- Domain owner: confirm inferred business intent, output keys, acceptable tolerances, corrections and scope.
- Developer: implement selected design with precise computation contracts.
- Reviewer: independently verify citations, graph completeness, numerical semantics, and claim-to-evidence linkage.

## Functional requirements (stable IDs)

| ID | Requirement | Acceptance evidence |
|---|---|---|
| REQ-01 | Inventory all authorized SAS, LOG, LST, includes, formats, configs and reference outputs without executing untrusted files | Reconciled scope manifest; source hashes; omissions rejected |
| REQ-02 | Build one canonical factual source record with operation/edge IDs, column and dataset lineage, state, run-linked log observations, uncertainties | Typed schema + source-aware verifier + golden graph eval |
| REQ-03 | Separate observed behavior, inferred intent, proposed requirement, assumption, hypothesis, measurement | Explicit classifications, versioned approvals/unknowns |
| REQ-04 | Draft master PRD, capability map, module SPECs and success criteria | Every criterion linked to behavior ID and planned test; unknowns unresolved |
| REQ-05 | Analyze composed modules and sequential blockers from eagle-eye data/log perspective | Dependency DAG, blockers, provenance, critical-path report |
| REQ-06 | Evaluate safe parallelism at workload, module, stage, feature, partition, expression, training levels | Feasibility report with proofs and counterexamples |
| REQ-07 | Generate multiple candidate ADRs with as-is/to-be Mermaid, HLD, LLD, algorithmic changes, alternatives and measurable tradeoffs | Candidate-by-candidate claim ledger and comparison |
| REQ-08 | Produce Spark, Ray, Dask and justified native/hybrid candidates; allow explicit exclusion | Runtime suitability analysis; no forced winner |
| REQ-09 | Draft downstream-compatible migration profile, tie-out contract, benchmark contract, candidate runtime settings | Valid draft semantics; unresolved values remain unapproved |
| REQ-10 | Independently verify assumptions before any human architecture selection | Semantic verifier catches true citation/false claim |
| REQ-11 | Package immutable, hash-bound handoff; receiving repo re-verifies and owns human approval | Manifest, provenance, source fingerprints, non-approval status |
| REQ-12 | Reassess existing ADRs when adding modules or source facts change | Impact graph; invalidation and revision test |
| REQ-13 | Demonstrate Jim Thompson practices via focused context, bounded stages, proportional model choice and evidence-based reviews | Run logs, focused-context audit, quality/cost comparisons |
| REQ-14 | Prevent secrets/PII leakage and prevent SAS code execution during discovery | Security test and redaction evidence |
| REQ-15 | Keep requirements, runtime and tie-out approval human-owned downstream | No auto-approval paths; negative gate tests |

## Success criteria and proof boundary

- **Pilot hard gates:** 100% synthetic scoped file inventory; no fabricated/invalid source hashes; no dangling dependency IDs; no false PASS on known unsafe parallelization; no fabricated measured speedup; no human approval impersonation; no source modification; no unapproved contract marked approved. These are **proposed pilot acceptance rules**, not validated reliability percentages.
- Accuracy: report precision/recall for known dependency edges and semantic claim classifications against withheld gold fixtures; report confidence intervals and coverage, not just an average score. Any critical false approval fails the pilot regardless of mean score.
- Architecture: each viable candidate includes concrete as-is/to-be graph, HLD, LLD, state/order assumptions, data movement, runtime constraints, tie-out obligations, and measurable benchmark hypothesis.
- Incremental: adding a module invalidates only affected downstream designs, with explicit impact report; unaffected artifacts retain provenance.
- Handoff: a receiving-side compatibility check must reject missing approval, stale hashes, unsupported fields and schema mismatches. It must not pretend an upstream draft is already approved.

## Non-goals in v1

No production SAS interpreter/parser guarantee; no executing arbitrary SAS; no automatic implementation, release or migration; no automatic PRD/ADR approval; no invented oracle, fixture, tolerances or performance results; no assumption that Spark always wins; no forced multi-agent architecture; no REA binary-analysis dependency; no silent modification of the existing repository.

## Risks and decisions requiring humans

Business intent cannot be fully inferred from code. Source-only graph completeness may be limited by dynamic macros/includes or inaccessible data. Training reproducibility may require stochastic/statistical criteria beyond keyed output parity. Decide downstream whether to accept corrected legacy behavior; version the change separately from optimization. Private data and logs must stay outside public Git by default.
