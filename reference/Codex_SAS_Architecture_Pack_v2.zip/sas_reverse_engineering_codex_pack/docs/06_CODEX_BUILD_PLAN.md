# 06 — Codex Implementation Plan and Acceptance Gates (Normative)

## Instructions to Codex

Create a **new repository** implementing the upstream read-only reverse-engineering and computation architecture planner described by this pack. Treat `README.md` and docs 01–08 as requirements; when conflicts arise, `02_ARCHITECTURE_AND_WORKFLOW.md` governs lifecycle/status/authority, `05_HANDOFF_AND_CONFIG.md` governs downstream compatibility, and source evidence outranks narrative. Do not modify `Agent-mastery` unless separately authorized. Do not claim features implemented until tests execute. Do not fabricate SAS source, source locations, human approvals, benchmark results, REA integration, or measured runtime improvements. Keep all synthetic fixtures clearly labeled. If an essential decision is unresolved, emit BLOCKED and a precise question.

## Phased implementation (each phase is independently reviewable)

**P0 — Baseline and repository bootstrap.** Pin existing downstream branch commit, inspect real schemas/config/skills, record compatibility matrix and unsupported assumptions. Scaffold project, CI, security/ignore rules, Python package, CLI, test harness, documentation, skill contracts. No business data committed. Acceptance: static structure/contract tests, frozen pinned references, reproducible environment.

**P1 — Source identity and evidence core.** Inventory and hash authorized SAS/log/LST/includes/config; build typed operation/edge/citation contracts; deterministic source-span/hash and graph validators; append-only sealed snapshots; explicit unresolved dynamic macros. Reuse existing trace extraction *knowledge* as a reference, not pretend it is an executable parser. Acceptance: fake hashes, missing file, negative line range, dangling edges, log mismatch rejected; positive synthetic inventory passes.

**P2 — Reconstruction and DAG.** Agent skill extracts SAS operation/column lineage and run-linked log observations with citations; independent source-aware checker; graph visualization. Acceptance: withheld gold graph fixtures for SET/MERGE, SQL, macros, BY/RETAIN, state, side effects; no inferred independence from mere sequential order.

**P3 — Parallelism and computation planner.** Identify critical path, independent waves, blockers, fusion/shared-prep candidates, feature and training opportunities; resource assumptions. Acceptance: independent feature case suggested, hidden producer-consumer and retained-state cases rejected, unknown blocked; theoretical speedup explicitly not measured.

**P4 — Requirements and ADR portfolio.** Draft master PRD/module SPEC and success criteria, candidate Spark/Ray/Dask/native ADRs, HLD+LLD Mermaid, as-is/to-be operation mapping, measurable tradeoffs, exclusions and cross-module impact. Acceptance: every material claim cites source evidence, no invented benchmarks, native runtime considered, 5-to-10 module growth scenario re-evaluated.

**P5 — Independent verification and evals.** Implement deterministic plus semantic verifier, separate checker context, withheld gold fixtures, frozen evaluator versions, pressure tests, claim/gate statuses. Acceptance: correct citation supporting false independence is `CONTRADICTED` and blocks package; zero critical false approvals in pilot fixtures; report coverage and limitations.

**P6 — Draft config and handoff.** Produce proposed profile/tie-out/benchmark/runtime plans and hash-bound manifest; validate draft compatibility against pinned downstream schemas; never emit APPROVED. Acceptance: stale/altered bundle fails; unapproved oracle/tolerance/population remains unresolved; downstream compatibility report clearly identifies required adapter.

**P7 — Integration demonstration (separate downstream approval).** Design/prototype receiving-side adapter in a separate branch/worktree only after authorization. Preserve interview/specify/decide and one-skill gates; human chooses and approves; trace verifies sealed source, map references graph IDs, IR conformance before generation. Acceptance: import cannot advance to generation without approval chain; changing source invalidates affected decisions.

## Proposed CLI (not implemented yet)

```text
sas-re discover --scope config/scope.yaml --run RUN-001
sas-re verify-source --run RUN-001
sas-re analyze-parallelism --run RUN-001
sas-re draft-requirements --run RUN-001
sas-re propose-adrs --run RUN-001 --candidates spark,ray,dask,native
sas-re verify-adrs --run RUN-001
sas-re package-handoff --run RUN-001
sas-re eval --suite all
```

All commands must be safe/read-only against intake; output only in run-scoped artifacts. No hidden automatic stage chaining; durable state controls allowed next step.

## Definition of done

A fresh checkout runs unit/schema/integration tests, documented adversarial cases, CI and a reproducible synthetic demo. Each skill has trigger, inputs, outputs, verification, boundaries, stop condition, evals, and explicit model-context budget strategy. Each report has PASS/FAIL/BLOCKED and limitations. Bundle integrity validated independently. Security and privacy tests pass. Documentation matches executable behavior; no 'implemented' claim from a markdown file alone.

## Non-negotiable failure tests

- Fabricated citation with correct format rejected.
- Real citation with wrong semantic conclusion rejected.
- Changed include/source/log after sealing invalidates dependent ADR.
- Missing macro or unknown state blocks claimed independence.
- Duplicate graph ID or formula owner rejected.
- False coverage totals rejected by derived counts.
- Candidate marks PRD, ADR or tie-out as human approved rejected.
- Different Spark/Ray/Dask tolerances for same required behavior rejected.
- Runtime benchmark `PASS` without actual measurements rejected.
- Candidate skill reads evaluator gold files rejected by access control.
- Two concurrent owners of singleton canonical path rejected.
- Added module exposes cross-module dependency and reopens affected design.
- Repair cannot change oracle/evaluator/PRD/ADR; retry cap enforced downstream.

## Codex prompt (copy/paste)

> Build a new repository from the attached SAS Reverse Engineering & Computation Architecture Planner pack. First read README and docs 01–08 and inspect the pinned Agent-mastery repository contracts. Produce a phased implementation plan and risk register; do not code until the plan and P0 scope are reviewed. Implement P0 then P1 only in the first iteration. Use a single authoritative workflow, run-scoped immutable evidence, deterministic validators, source-grounded claim checking, and no human self-approval. Do not execute untrusted SAS. Create synthetic positive/negative fixtures and run tests. Report exact commands, results, changed files, remaining gaps, and a copy-ready next phase. Do not claim performance gains or downstream compatibility without executable evidence.


## Mandatory detailed lesson references

Before implementation read `09_REA_CASE_STUDIES_AND_IMPLEMENTATION_LESSONS.md`, `10_ENGINEERING_PRACTICES_TO_EXECUTABLE_CONTROLS.md`, `11_REPOSITORY_AUDIT_TO_IMPLEMENTATION_TRACEABILITY.md`, and `12_FINAL_ONE_SHOT_CHECKLIST.md`. Use the final checklist as a tracked acceptance ledger. Do not mark implementation items complete from documentation-only checks.
