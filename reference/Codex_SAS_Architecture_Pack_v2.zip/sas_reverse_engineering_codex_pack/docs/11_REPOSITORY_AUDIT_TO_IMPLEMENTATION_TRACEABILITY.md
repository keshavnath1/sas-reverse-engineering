# 11 — Existing Agent-mastery audit: exact lessons and new-repo implications

**Baseline:** [Agent-mastery at audited commit bc754e0](https://github.com/keshavnath1/Agent-mastery/commit/bc754e0f1204a99020c864df2a5b25983005e09c). **Source:** `references/Early_discovery_can_reuse_trace_knowledge—but_the_.md`. The 43 passing smoke tests and synthetic schema probes are reported by the user-provided audit; this pack does not reproduce them.

## What is reusable and what is not

- `trace/references/sas-trace-contract.md` is a rich **instructional extraction contract**, **not an executable SAS parser**. Reuse its vocabulary for macros, DATA/PROC steps, includes, logs/LST, row counts, state, order and citations. Do not claim automatic parser accuracy.
- `trace` owns source facts; `map` currently reconstructs some dependencies again because trace schema lacks typed graph edges. New repo must produce stable operation/edge IDs and validate graph completeness. Downstream trace should verify/reuse, downstream map should assign ownership without silently rewriting facts.
- Existing `config/workflow.yaml` and `AGENTS.md` define one-skill/human gates, but synthetic probes reportedly accepted generation-ready state without approvals. New repo cannot grant downstream approval. Its handoff is candidate evidence only.
- Existing `import` is for approved reusable patterns, **not** a generic PRD/ADR bundle importer. New receiving-side reconciliation adapter is a separate proposal and needs an explicit change in Agent-mastery.
- `diagnose` reads failure evidence, SPEC and ADRs but does not mandate cross-check of PRD, trace, map and IR. The new repo should emit a claim-to-artifact matrix to make downstream root-cause attribution possible, without replacing `diagnose`.

## Required negative tests from audit

| Reported weakness | Required implementation guard | Test outcome |
|---|---|---|
| Fake or stale citation/hash accepted | Resolve file path, SHA-256, valid line range, exact excerpt and run identity | FAIL/BLOCKED |
| Flat dataset lists without typed graph | Require producer/consumer/ordering/state/side-effect edge IDs | FAIL if dangling/omitted |
| False mapping coverage totals | Derive coverage from unique source operation IDs; reconcile every ID | FAIL |
| Duplicate or empty semantic owner | Unique owner with nonempty ID and explicit adapter boundary | FAIL |
| Generated-ready state with no approvals | Downstream independent approval history and exact hash chain | BLOCKED |
| Scope/include changes after sealing | Compare complete fresh inventory, preserve old snapshot and invalidate consumers | BLOCKED |
| Global newest run selected | Explicit module/run/attempt IDs and workspace owner lock | FAIL/BLOCKED |
| Copilot evals not in maintained smoke suite | Separate real skill-eval harness and CI checks with withheld answers | NOT_RUN until built |

## Canonical handoff and ownership

New repo produces a sealed candidate bundle with a single source-fact graph and derived PRD, SPEC, ADR, diagram and config drafts. Downstream retains exact canonical paths: `stage1_extraction/output/execution_trace.json`, `policy/policy_registry.yaml`, `artifacts/semantic_ir/<module>.json`, `artifacts/evidence/runs/<run-id>/attempts/<attempt-id>/`. New repo does **not** write these directly in a live downstream workspace or call an existing approval complete.

Before Codex generates implementation, it must inspect current branch HEAD and report drift from audited commit. If contracts differ, stop and reconcile, rather than changing our specification silently.

## Verification layering

1. JSON Schema validates shape; 2. deterministic validators check hashes, inventory, graph, cross-artifact coverage, states; 3. independent source-aware semantic reviewer tests whether citations actually support claims; 4. downstream human decides; 5. post-generation tie-out and benchmarks measure results. No one layer substitutes for another.
