# 09 — REA case studies: transferable implementation lessons

**Status:** case-study interpretations from the earlier conversation; links below are research references, **not independently reproduced experiments**. REA is neither a proven SAS parser nor a mandatory dependency. Before borrowing code, Codex must inspect the current repository, licenses, APIs, and example source.

## DX-Ball: behavioral reconstruction, not plausible translation
Reference: [DX-Ball showcase](https://rea.tools/showcase/dx-ball/) · [REA](https://github.com/morluto/rea)

**Previously discussed demonstration:** recover a calculation from lower-level instructions and compare reconstruction against original behavior. Previously reported counts (3,205 cases and 63 compiled bytes) are case-study claims, not measurements reproduced in this pack.

**Implementation transfer:** (1) Inventory the original SAS sources and log/LST run identities; (2) extract operations with stable IDs and exact source spans; (3) derive semantic assertions for each operation; (4) verify source-to-log consistency and locked SAS oracle examples; (5) emit `does_not_prove` for untested inputs. A source citation alone is insufficient: a syntactically valid citation can contradict the claim.

**Skill/contract targets:** `reconstruct`, `verify-claims`, `source_record.schema.json`, `claim.schema.json`. Store evidence locator, hash, observed behavior, inference and alternative explanation. The verifier must be independent of the proposing agent.

**Adversarial eval:** a claim says branches are independent but the cited SAS `SET` reads an earlier output. Citation-validity must PASS while semantic support is CONTRADICTED; the ADR gate FAILS.

## Notion: cross-boundary feature tracing
Reference: [Notion showcase](https://rea.tools/showcase/notion/)

**Previously discussed demonstration:** follow a feature across multiple process and messaging boundaries rather than stopping at its first entry point.

**Implementation transfer:** construct a *program-wide* SAS dataset/column lineage graph covering `%include`, macro calls, LIBNAMEs, physical tables, intermediate datasets, file exports, orchestration and downstream consumers. Use separate observed-order edges and required-dependency edges. When module 11 arrives, perform graph-diff and impact analysis on ADRs for modules 1–10.

**Skill/contract targets:** `analyze-execution`, `analyze-parallelism`, `evaluate-designs`. Every edge has producer/consumer IDs, evidence, confidence/unknown status and side-effect metadata. Missing macro expansion means UNKNOWN, never INDEPENDENT.

**Adversarial eval:** a downstream consumer is outside the initially selected module. Discovery must report incomplete scope and block unsafe fusion or deletion of the intermediate dataset.

## TH04: exact numeric and execution semantics
Reference: [TH04 showcase](https://rea.tools/showcase/th04/)

**Previously discussed demonstration:** reconstruct historical arithmetic where integer widths, wraparound and operation order matter. A previously reported compiled-byte match is not independently reproduced here.

**Implementation transfer:** build per-module numerical contracts: SAS missing/NULL rules, floating-point evaluation order, retained state, BY/FIRST./LAST., date/time, precision, formats, sort stability, deterministic random seeds, training coefficients and convergence. Distinguish exact parity from approved statistical equivalence. Parallel reduction may change summation order and results; no tolerance relaxation without approval.

**Skill/contract targets:** `reconstruct`, `design-computation`, `verify-architecture`, `MODULE_SPEC.md`, candidate ADR numerical obligations.

**Adversarial eval:** Spark distributed aggregation changes order; the candidate must document a tie-out plan and uncertainty, not claim bitwise equivalence.

## RL environment builder: repeatable agent evaluation
Reference: [RL environments guide](https://rea.tools/guides/rl-environments/)

**Previously discussed demonstration:** reconstruct an interactive test environment from observed interfaces; distinguish runnable test scaffolding from fidelity to the real application.

**Implementation transfer:** build a hermetic SAS-evidence fixture set with known source, log, expected graph, and withheld evaluator answers. Candidate skill receives only fixture inputs. Independent grader gets gold answers in a separate path/process inaccessible to candidate tools. Test missing logs, forged hashes, misleading order, changed includes, source/log mismatch, incorrect owner, stale approval and unsafe parallelization. Evaluate detection AND false-positive rates.

**Skill/contract targets:** `evals/golden`, `evals/adversarial`, `evals/graders`; evaluate every skill revision and preserve exact skill/evaluator hashes.

**Adversarial eval:** candidate attempts to read expected answers; test harness denies access and records a violation. Passing an agent task does not prove environment fidelity.

## Cross-case adoption decision

| Pattern | Adoption | Evidence required before production |
|---|---|---|
| Source-grounded semantic reconstruction | Design requirement | source/log/oracle gold fixtures and false-citation evals |
| Cross-module dependency lineage | Design requirement | graph edge recall/precision and incremental module impact tests |
| Numeric semantic contract | Design requirement | numerical edge cases and tie-out with locked tolerances |
| Hermetic adversarial skill environments | Design requirement | hidden gold isolation, repeatable CI, negative-case coverage |
| REA code/MCP integration | **Deferred experiment** | current API/license/security review and SAS-specific utility benchmark |

**Do not claim:** REA has native SAS support; our parser already exists; case-study numbers were independently replicated; or any performance improvement is measured.
