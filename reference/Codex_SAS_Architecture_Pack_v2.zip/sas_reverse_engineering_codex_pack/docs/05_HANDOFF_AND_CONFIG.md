# 05 — Downstream Handoff and Configuration Drafting (Normative)

## Exact baseline fields inspected

At the reviewed branch, `config/migration_profile.yaml` is **profile_version 2**, `status: UNAPPROVED_TEMPLATE`, with `module_id`, `business_outcome`, `migration_mode`, `source_runtime: SAS`, `semantic_runtime`, `semantic_implementation`, `selected_adapter`, `cluster_execution`, `local_tieout_requested`, `tieout_population` fields and `human_approval_required`. It says populate through **interview and human approval**.

`config/tieout.yaml` is `UNAPPROVED_TEMPLATE`, `contract_version: template-3` and has `scope`, `key_columns`, `intake_manifest`, `oracle`, `fixture_manifest`, `producer`, `comparisons`, `decision_basis`, `output`, `privacy`, `oracle_lock`. `contracts/tieout_contract.schema.json` constrains population choices, phases, comparison modes, approval and privacy. An approved tie-out needs a real locked oracle, fixture, selector and human-authorized values; these cannot be inferred from source alone.

## Draft strategy — no fake approval

- Export `proposed_migration_profile.yaml` in the downstream field structure with `status: UNAPPROVED_TEMPLATE` or another **downstream-schema-supported** draft status only after checking validator behavior. Keep `selected_adapter`, runtime, population and approval fields null until selected downstream; candidate-specific runtime suggestions belong in **separate ADR candidate plan** files, not authoritative profile fields.
- Export `proposed_tieout.yaml` using downstream `DRAFT` status, real known evidence references where safe, null/empty unresolved fields, and explicit human decision questions. **Do not claim it is executable or schema-valid as APPROVED.** An unresolved producer command is intentionally empty until code generation; fixture and oracle locks cannot be invented.
- Export `benchmark_contract.yaml` as a **new proposed upstream schema**, not an existing Agent-mastery contract. It states baseline, workloads, repetitions, hardware, cache, input/output and objective; results remain `NOT_RUN` until executed.
- Export one `candidate_runtime_plan.yaml` per Spark/Ray/Dask/native ADR; these are advisory, not the approved `migration_profile.yaml`.
- Record per-field provenance: `SOURCE_OBSERVED`, `BUSINESS_PROPOSED`, `HUMAN_REQUIRED`, `RUNTIME_HYPOTHESIS`. Never infer acceptance criteria from row counts alone.

## Handoff layout

```text
handoff/<bundle-id>/
  manifest.json
  source_record.json
  dependency_graph_view.json             # derived only, references source_record hash
  execution_analysis.json                # run-linked observations
  parallelism_opportunities.json
  docs/master_prd.md
  docs/module_specs/<module>.md
  docs/adrs/<module>-spark.md
  docs/adrs/<module>-ray.md
  docs/adrs/<module>-dask.md
  docs/adrs/<module>-native.md            # if viable
  docs/adrs/cross_module.md
  docs/adr_comparison.md
  configs/proposed_migration_profile.yaml
  configs/proposed_tieout.yaml
  configs/benchmark_contract.yaml
  configs/candidate_runtime_plan-<runtime>.yaml
  evidence/claim_verification.json
  evidence/eval_results.json
  evidence/assumptions_report.md
```

Every file in `manifest.json` has relative path and SHA-256, source scope, upstream version, skill/evaluator versions, no approval assertion, privacy classification and explicit limitations. Bundle must be immutable; revision creates a new ID.

## Receiving-side import protocol (to implement separately)

1. Pin downstream repo commit and schemas; reject incompatible version without migration plan.
2. Verify manifest/file hashes, source scope, privacy, evidence IDs, no critical unsupported claims, candidate status only.
3. Present proposals to downstream `interview` and `specify`; human decides business intent and tie-out population, approves PRD/SPEC and draft contract. Do **not** use existing pattern `import` as a bypass.
4. Present ADR candidates to `decide`; independent evidence check, comparison and **human selection**. Then `trace` reconciles/reuses sealed source evidence, `map` assigns ownership, `model` builds IR and passes conformance before `generate`.
5. `test` locks governed fixture/oracle and receives human approval; `validate` uses generic keyed tie-out. Selected-runtime adaptation/benchmark requires real cluster evidence and separate review/release.
6. Any source/hash/requirement change invalidates affected downstream approval chain and requires authorized re-entry. Retain immutable history and attempts.

## Configuration compatibility tests

- Profile draft has exact known baseline keys; no invented approval state or selected runtime.
- Tie-out draft validates under downstream JSON schema as `DRAFT` **when all required structural fields are populated**; it must fail or block any attempt to mark `APPROVED` without required human decisions and hashes.
- `oracle_lock` stays `UNAPPROVED`; `privacy.hash_keys_in_evidence=true`, `include_values_in_evidence=false`.
- Population is never defaulted to `GOVERNED_SAMPLE_50` from convenience. Human selection remains mandatory.
- Cross-candidate tie-out keys, metrics and tolerances are shared; only runtime-specific producer plans may differ after selection.

## Important boundary

A validated draft package proves integrity and readiness for **human review**, not semantic parity, production suitability, optimization speedup, or authorization to generate code.
