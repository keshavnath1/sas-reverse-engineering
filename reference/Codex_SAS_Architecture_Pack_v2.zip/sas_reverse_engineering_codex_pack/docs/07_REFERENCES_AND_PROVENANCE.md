# 07 — Sources, Reference Links, Evidence Strength

## Existing repository — primary implementation baseline

Pinned audit commit: [`bc754e0f1204a99020c864df2a5b25983005e09c`](https://github.com/keshavnath1/Agent-mastery/commit/bc754e0f1204a99020c864df2a5b25983005e09c). Working branch: [`feature/governed-learning-memory`](https://github.com/keshavnath1/Agent-mastery/tree/feature/governed-learning-memory). **Do not assume branch HEAD still equals pinned audit commit.**

- [AGENTS.md — operating and human authority contract](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/AGENTS.md)
- [config/workflow.yaml — current downstream lifecycle](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/config/workflow.yaml)
- [config/migration_profile.yaml — actual profile template](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/config/migration_profile.yaml)
- [config/tieout.yaml — actual tie-out draft template](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/config/tieout.yaml)
- [contracts/tieout_contract.schema.json — actual tie-out schema](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/contracts/tieout_contract.schema.json)
- [trace/SKILL.md](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/trace/SKILL.md)
- [trace SAS extraction contract](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/trace/references/sas-trace-contract.md)
- [trace schema](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/trace/schemas/execution_trace.schema.json)
- [map/SKILL.md](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/map/SKILL.md)
- [map schema](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/map/schemas/policy_registry.schema.json)
- [map behavior mapping contract](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/map/references/behavior-mapping-contract.md)
- [specify/SKILL.md](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/specify/SKILL.md)
- [decide/SKILL.md](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/decide/SKILL.md)
- [import/SKILL.md — pattern reuse, NOT general PRD import](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/import/SKILL.md)
- [diagnose/SKILL.md](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/.github/skills/diagnose/SKILL.md)
- [run-state schema](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/contracts/run_state.schema.json)
- [tie-out runner](https://github.com/keshavnath1/Agent-mastery/blob/bc754e0f1204a99020c864df2a5b25983005e09c/scripts/run_tieout.py)

## Uploaded audit (included under references/)

`Early_discovery_can_reuse_trace_knowledge—but_the_.md` is the user's audit of commit `bc754e0` (2026-11-04). It reports 43 passing smoke tests but synthetic schema probes accepting fabricated citations, fake trace hashes, false map coverage and generate-ready state without approval history. **Those results are reported by the audit; this pack did not independently rerun its smoke tests or inspect its separate probe JSON/log, which were not provided.** Audit recommendation: one sealed factual record; discovery captures, later trace verifies, map owns target assignment.

## Jim Thompson guide (included under references/)

`Jim Thompson Best Practices_ A Deep Learning Guide.md` (author listed as Manus AI) explains proportional model selection, focused context, proportional planning, open/closed loops, bounded retries, selective subagents, caching and measurable results. It is **guidance**, not a claim that model routing or quota controls are programmatically available in every Copilot environment.

- [Jim Thompson coding assistant practices](https://github.com/jimthompson5802/coding-assistant-practices)
- [GitHub Copilot model auto-selection](https://docs.github.com/en/copilot/concepts/models/auto-model-selection)
- [VS Code agent context](https://code.visualstudio.com/docs/agents/concepts/context)
- [GitHub Copilot agent delegation](https://docs.github.com/en/copilot/concepts/agent-capabilities/choosing-and-delegating-agent-work/delegating-and-parallelizing-work-with-agents)

## REA — inspiration, not dependency

- [REA repository](https://github.com/morluto/rea)
- [REA website](https://rea.tools)
- [DX-Ball showcase](https://rea.tools/showcase/dx-ball/)
- [Notion showcase](https://rea.tools/showcase/notion/)
- [TH04 showcase](https://rea.tools/showcase/th04/)
- [RL environments guide](https://rea.tools/guides/rl-environments/)

Earlier conversation summarized REA use cases as behavior reconstruction, cross-process tracing, numerical semantics recovery and reproducible environments. **These case-study descriptions and URLs were not independently re-fetched or reproduced in this packaging pass**. Codex should verify current pages and licensing before adopting specific code/tools. Transferable principle: evidence-backed reconstruction, cross-boundary lineage, numerical exactness, controlled evals. REA is not shown to be a native SAS parser or migration engine.

## Runtime technical references

- [Spark SQL performance tuning](https://spark.apache.org/docs/latest/sql-performance-tuning.html)
- [Spark job scheduling](https://spark.apache.org/docs/latest/job-scheduling.html)
- [Ray documentation](https://docs.ray.io/en/latest/)
- [Dask documentation](https://docs.dask.org/en/stable/)
- [NumPy documentation](https://numpy.org/doc/stable/)

These references support capability investigation, **not a workload-specific performance verdict**. Runtime versions and deployment constraints must be pinned in the implementation.

## Provenance labels

- **Verified against retrieved repo text:** exact baseline profile/tie-out fields, trace/map/decide/specify/import skill responsibilities and workflow configuration (subject to pinned commit).
- **Reported in uploaded audit:** 43 smoke tests and schema-probe findings; not independently rerun here.
- **Source-derived from uploaded Jim guide:** engineering practices, not product guarantees.
- **Design proposals:** new repository, skills, schema, DAG analysis, candidate ADRs, handoff adapter, benchmarks and acceptance thresholds.
- **Unverified:** REA showcase execution, real SAS extraction accuracy, real runtime improvements, integration with a live Agent-mastery migration.


## Detailed application notes in this pack

- [REA case studies and implementation lessons](09_REA_CASE_STUDIES_AND_IMPLEMENTATION_LESSONS.md)
- [Jim Thompson engineering controls](10_ENGINEERING_PRACTICES_TO_EXECUTABLE_CONTROLS.md)
- [Agent-mastery audit remediation](11_REPOSITORY_AUDIT_TO_IMPLEMENTATION_TRACEABILITY.md)
- [One-shot final checklist](12_FINAL_ONE_SHOT_CHECKLIST.md)
