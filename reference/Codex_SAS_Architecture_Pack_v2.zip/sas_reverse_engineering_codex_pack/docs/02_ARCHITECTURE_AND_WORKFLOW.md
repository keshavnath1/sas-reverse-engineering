# 02 — Authoritative Architecture, State and Workflow (Normative)

## Exactly one upstream workflow

```mermaid
flowchart TD
 I[Authorized read-only intake] --> O[Inventory and seal source identity]
 O --> R[Reconstruct source operations and log-linked observations]
 R --> V[Independent source/graph evidence verification]
 V -->|FAIL/BLOCKED| R
 V -->|PASS| P[Draft master PRD and module SPECs]
 P --> A[Analyze DAG and parallelization blockers]
 A --> D[Generate candidate ADR HLD/LLD and draft configs]
 D --> C[Independent claim and ADR evidence verification]
 C -->|FAIL/BLOCKED| D
 C -->|PASS| X[Compare alternatives and package draft handoff]
 X --> H[Downstream independent reconciliation and human gates]
```

**This is the sole normative upstream sequence.** Downstream Agent-mastery retains its own authoritative `config/workflow.yaml`; do not present this as an already authorized extension of that repository. Any cross-repo integration must be explicitly implemented and approved.

## Artifact ownership (no duplicate truth)

| Artifact | Owner | Source of truth? | Authority |
|---|---|---|---|
| Scoped source manifest | inventory | yes for file identity | observation only |
| Sealed source record/operation and edge graph | reconstruct | **sole factual source authority** | source-backed candidate facts |
| Execution timeline and timings | reconstruct | derived, run-specific | observed for linked run only |
| Parallelism opportunities | analyze-parallelism | derived | hypotheses until verified |
| Master PRD and module SPECs | draft-requirements | draft | not human-approved |
| Spark/Ray/Dask/native ADRs | propose-adrs | draft | not selected |
| Evidence verification results | independent verifier | verifier's signed/versioned result | evidence check, not approval |
| Draft migration/tie-out/benchmark config | package-handoff | draft | cannot be executable approved contract |
| Approved PRD/SPEC/ADR, oracle/tolerances, release | **Agent-mastery/humans** | downstream authoritative | human decision |

## Canonical source record contract

Use `source_record.json` per module/run workspace, sealed with SHA-256. Stable operation IDs and edge IDs; source file SHA, 1-based line span, excerpt hash; observed vs inferred classification; produced/consumed dataset and column nodes; macro/includes, dynamic resolution and unknowns; log source/run link; rows, elapsed/CPU, warnings; state/reset, sort/BY, missing value and numerical semantics. One edge may be `DATA`, `STATE`, `ORDER`, `SIDE_EFFECT`, `RESOURCE`, or `UNKNOWN`; resource is scheduling, not semantic dependency. Preserve raw facts separately from inferred edges. All derived artifacts cite these IDs and sealed content hash.

Do not call a schema-valid artifact complete. Validate hashes, locators, scoped file coverage, graph referential integrity, semantic citations and source/log linkage. Unknown dependencies must remain unknown; no 'no edge found' => 'independent' inference. If source changes, issue a new sealed version and invalidate impacted claims/ADRs. Do not overwrite history.

## Downstream boundary and non-bypass

Agent-mastery currently orders `interview → specify → decide → [optional harvest/import] → trace → map → model → generate → test → validate → adapt → ingest → review → release → learn`. Existing `import` is for compatible reusable *patterns* after approved PRD/SPEC/ADRs, not general PRD/ADR import. A **new receiving-side proposal intake/reconciliation adapter** must be separately specified and authorized. It may prefill candidate drafts but cannot mark approvals, skip stages, alter oracle/tolerances or silently replace canonical artifacts.

Canonical downstream compatibility paths must remain:

```text
stage1_extraction/output/execution_trace.json
policy/policy_registry.yaml
artifacts/semantic_ir/<module>.json
artifacts/evidence/runs/<run-id>/attempts/<attempt-id>/
```

The upstream source record is a **handoff candidate**. Downstream `trace` must verify/reuse its operation and edge IDs after authorized approval; `map` assigns target semantic/adapter/test ownership, without rebuilding or silently changing factual edges. If a contradiction emerges, reopen the earliest affected requirements/ADR/source gate. Model IR conformance checks approved SPEC invariants and selected ADR; do not require completed IR before it exists.

## State and isolation

- Explicit `workspace_id`, `module_id`, `run_id`, `attempt_id`, source manifest SHA, source record SHA, upstream stage, prior gate, and artifact hashes. Never infer active run by newest mtime.
- Separate worktrees or run roots for concurrent modules; first pilot permits one owner per singleton downstream canonical path.
- Atomic state writes, append-only attempts, immutable evidence snapshots, idempotent reruns and hash-bound invalidation.
- Roles: maker drafts; independent checker challenges; orchestrator routes; **only human downstream approves**. No maker changing gold/evaluator/tolerance to obtain PASS.
- On failure route to **earliest failed gate**. Local implementation defects get bounded repair; changed business intent or architecture assumptions reopen upstream review. Preserve existing downstream max three repair attempts and stop after two repeats without new evidence.

## Status taxonomy (normative across every file)

- `claim_classification`: `OBSERVATION | INFERENCE | ASSUMPTION | HYPOTHESIS | MEASUREMENT`
- `claim_verification`: `VERIFIED | PARTIAL | UNSUPPORTED | CONTRADICTED | UNVERIFIABLE`
- `stage_gate`: `PASS | FAIL | BLOCKED`
- `benchmark_execution`: `NOT_RUN | PASS | FAIL | BLOCKED`
- `artifact_authority`: `DRAFT | EVIDENCE_CHECKED | HUMAN_APPROVED | REJECTED | SUPERSEDED` (upstream **must not** emit `HUMAN_APPROVED`)

A hypothesis can be VERIFIED as *well-grounded rationale* while `benchmark_execution=NOT_RUN`; never represent it as measured improvement. Missing evidence is UNVERIFIABLE/BLOCKED, not automatically UNSUPPORTED or PASS.
