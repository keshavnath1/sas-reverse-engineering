# 08 — Showcase Script, Evidence Artifacts and Honest Claims

## Demo A — Discover parallelism from composed SAS modules

Use synthetic source and logs showing three sequential feature stages with independent inputs and no shared state. Display as-is sequential timeline, source DAG, operation IDs, observed counts and durations, critical path and to-be HLD/LLD. Show source spans behind each edge and the distinction between observed order and required order. Verify no 'speedup achieved' claim without runtime execution.

## Demo B — Reject a plausible but unsafe ADR

Inject `SET work.scenario_a` into Scenario B or retained-state coupling. Spark ADR incorrectly says A and B are independent, citing the correct SAS lines. Citation checker passes locator; semantic verifier returns `CONTRADICTED`, gate `FAIL`, identifies exact edge and blocks handoff. This demonstrates why schema validation is insufficient.

## Demo C — Compare Spark, Ray, Dask and native computation

Generate four candidate ADRs (or explicit exclusions) with HLD/LLD and measurable performance hypotheses. Compare end-to-end latency, memory, shuffle/data transfer, deployment complexity, training reproducibility and growth. Mark benchmarks `NOT_RUN` until real measurements. Show same shared correctness contract for all.

## Demo D — Incremental module growth

Start with five synthetic modules, then add five with one new cross-module dependency. Show versioned graph change, affected ADR invalidation, revised critical path and integration risk; unaffected source observations retain their hashes.

## Demo E — Jim Thompson practices in execution

Show progressive context loading (file/line queries), planning checkpoints, one bounded skill per stage, independent checker, frozen eval hashes, retries and costs where available. Compare against a baseline using task quality, total agent calls, latency and measured usage; do not claim quota savings without authoritative reports. Show how agent-level parallelism differs from computational parallelism.

## Required demo artifacts

- `source_manifest.json`, `source_record.json`, DAG diagrams, citations and hashes
- `parallelism_opportunities.json`, blockers and critical path explanation
- PRD, module SPECs, cross-module ADR, runtime candidate ADRs with HLD/LLD
- `claim_verification.json` and deliberately failed case
- `eval_results.json` including negative cases and limitations
- proposed `migration_profile.yaml`, `tieout.yaml`, benchmark contract and manifest
- CLI commands, exit codes, verifier version, commit, redacted logs

## What the demonstration proves and does not prove

A passing synthetic demonstration supports **the tested evidence workflow** and the ability to detect known unsafe assumptions. It does **not** prove all SAS constructs are covered, full-population equivalence, target-cluster speed, production reliability, or that one runtime is universally optimal. Only the downstream approved code + SAS oracle tie-out and representative runtime benchmarks can establish those narrower claims.
