# 04 — Evidence Verification, Skill Evals and Adversarial Assurance (Normative)

## Claim-evidence discipline

Every material claim has stable `claim_id`, source operation/edge IDs, classification, exact source locator (path, SHA, 1-based lines, excerpt hash), linked log run/step when applicable, supporting and contradicting evidence, preconditions, `claim_verification`, rationale and limitations. Distinguish *locator exists* from *semantic support*: a real source span can contradict a parallelization recommendation. No chain-of-thought storage; capture observable claims, evidence and verdicts only.

## Three independent verification layers

1. **Schema/static:** required fields, enum values, unique IDs, hash format, approved status restrictions, nonempty owners, no raw records.
2. **Deterministic cross-artifact:** recompute file hashes; verify citation bounds/excerpt hashes; source scope completeness; graph referential integrity; counts derived from IDs; run/log provenance; stable operation IDs; source-record SHA; ADR claims bound to exact evidence version; YAML draft compatibility; no dangling dependencies.
3. **Independent semantic reviewer:** challenge edge meaning, missing state, log inference, numerical equivalence, technology assumptions, and false independence. Use negative evidence and counterexamples; may return `UNVERIFIABLE` when source insufficient. Checker must not edit candidate or gold.

## Eval suites

| Suite | Golden / adversarial cases | Core metric |
|---|---|---|
| Inventory | omitted include, stale manifest, fake hash, duplicate file | scoped coverage and hash validity |
| SAS reconstruction | SET/MERGE/SQL joins, macro includes, RETAIN, LAG, BY/FIRST/LAST, missing values, run mismatch | edge precision/recall, critical misses |
| Log interpretation | elapsed vs CPU, row counts, warnings, zero rows, repeated scans, unmatched log | correctly grounded observations |
| Parallelism | independent features; hidden shared state; cross-module dependency; global sort; side effects | unsafe proposal rejection rate |
| ADR claims | fabricated citation; valid citation/wrong inference; unsupported 40% speedup; Spark scheduler misconception | critical false approvals = 0 in pilot |
| ADR portfolio | Spark/Ray/Dask/native, justified exclusions, HLD/LLD, scale and rollback | mandatory-field and rationale coverage |
| Numerical | floating reduction order, SAS missing values, date/time, logistic frozen coefficients | invariant and tolerance correctness |
| Handoff | stale source, missing approval, schema mismatch, unapproved population, oracle substitution | import rejection correctness |
| Lifecycle | no self-approval, one skill per authorized step, attempt isolation, retry cap | state-transition compliance |
| Evolution | add 5/10 modules; new producer/consumer edge; changed include | impact/invalidation correctness |
| Security | prompt injection inside SAS comments/logs, PII, secret paths, malicious attachment | no execution or leakage |

## Withheld gold design

- Candidate skills see source fixtures, contracts and allowed evidence, **not** gold answer files.
- Gold files live in a separate evaluator-only location/account/process with access controls; prompts alone do not enforce isolation.
- Evaluator compares graph edges, semantic support and gate results, and records false positive/negative cases. Freeze evaluator hashes before runs; changing gold is a separate reviewed baseline change.
- Run deterministic unit tests on every change; run agent evals on representative and pressure fixtures before promotion. No aggregate score excuses a critical false approval.

## Example must-fail case

SAS operation B `SET work.scenario_a`, where A creates `work.scenario_a`. An ADR says A and B are independent and cites the correct source lines. Citation verification = valid; semantic verification = `CONTRADICTED`; ADR gate = `FAIL`; generation/approval blocked. The verifier must cite the exact producer-consumer edge, not merely say 'unsafe'.

## Failure attribution and recovery

Use existing downstream `analyze-failure → ingest/diagnose → human-approved bounded repair → review` only after downstream execution. Extend its future cross-artifact diagnostic to check PRD success criterion → source record/trace → map ownership → semantic IR → selected ADR → implementation/runtime/tie-out, identify earliest failed gate, and route specification/architecture defects upstream rather than 'fixing' expected outputs. Existing diagnose currently requires SPEC, ADRs, evidence, implementation diff and prior attempts; it does not explicitly require trace/map/IR, so this is a **proposal**, not current functionality.

## Status and reports

Use the exact taxonomy in `02_ARCHITECTURE_AND_WORKFLOW.md`. Produce `claim_verification.json`, `coverage.json`, `eval_results.json`, and human-readable `assumptions_report.md` with pass/fail/block reasons, affected artifact hashes, missing proof, and reproducible command IDs. Each stage verdict must distinguish observed evidence from benchmark measurements. A schema PASS alone is not semantic PASS.

## Pilot pass conditions

All golden positive cases pass; all critical negative cases are rejected; no false evidence/approval/performance claim; complete reproducible verifier logs; reviewer independence; no raw data leaks. Report number and variety of fixtures and limitations. This pilot cannot establish generalized reliability across arbitrary SAS workloads or production runtime performance.
