# 12 — One-shot checklist: contents, implementation and proof boundaries

Use this checklist as Codex's completion ledger. `INCLUDED` means **specified in this ZIP**, not implemented. `NOT_RUN` means no real SAS or runtime verification was executed.

## Specification coverage

- [x] Mission, non-goals, new-versus-existing repo responsibilities (`01`, `02`)
- [x] One authoritative workflow; candidate outputs and human downstream approval (`02`)
- [x] Sealed single source evidence record, operation/edge IDs, hashes, unknowns (`02`, `04`, contracts)
- [x] SAS source, LOG, LST, macro/include, dataset/column, state, ordering, provenance (`02`, `11`)
- [x] Master PRD, module SPEC, success criteria, capability mapping and traceability (`01`, templates)
- [x] Observed order versus required dependency; parallelism blockers and critical path (`03`)
- [x] Whole-workload, cross-module, stage, feature, partition, expression and training parallelism (`03`)
- [x] Multiple Spark/Ray/Dask/native/NumPy/hybrid candidate ADRs, justified exclusions (`03`, template)
- [x] As-is/to-be Mermaid, HLD and computation LLD per candidate (`03`, template)
- [x] Quantified hypotheses versus measurements; correctness/performance separate (`03`, `04`)
- [x] Claim status taxonomy, adversarial verifier, hidden gold and gate controls (`04`, evals)
- [x] Draft `migration_profile.yaml`, `tieout.yaml`, benchmark and runtime config (`05`)
- [x] Downstream exact schema compatibility, import limitations and immutable handoff (`05`, `11`)
- [x] Bounded failure attribution and incremental architecture impact (`02`, `04`, `11`)
- [x] REA DX-Ball, Notion, TH04, RL lessons with transfer tests (`09`)
- [x] Jim Thompson practices translated to executable controls and demos (`10`)
- [x] Existing Agent-mastery audit weaknesses and mandatory negative tests (`11`)
- [x] Phased Codex implementation and showcase acceptance tests (`06`, `08`)
- [x] Pinned primary links, research links, provenance labels and caveats (`07`, `09`–`11`)
- [x] Verification script, file hashes, packaging report and ZIP integrity (`verification/`)

## Implementation acceptance (Codex must demonstrate, not assume)

- [ ] Run deterministic source inventory/hash/locator and graph checks on synthetic gold fixtures
- [ ] Demonstrate source-fact sealing and downstream reuse without duplicate factual graph
- [ ] Reject citation-valid but semantically false parallelization claim
- [ ] Reject missing includes, altered log run IDs, stale hashes and unsupported numeric equivalence
- [ ] Generate 3 independently evaluated ADRs with HLD, LLD and comparable proof obligations
- [ ] Generate config drafts compatible with actual pinned downstream schemas, without fake approvals
- [ ] Prove hidden gold answers inaccessible to candidate agent
- [ ] Prove per-run isolation, bounded retries and downstream approval preservation
- [ ] Measure critical path, end-to-end benchmark and resource cost on documented workload
- [ ] Rerun full evaluations after any skill, schema, evaluator or source contract change

## Verification status of this ZIP

- **Package structure, JSON syntax/schema definitions, Markdown fences, internal links, hashes:** verified by `verification/verify_pack.py` (see report).
- **External URLs:** documented, not all fetched/revalidated at packaging time.
- **REA cases:** previously researched, not independently rerun.
- **Audit's 43 tests:** reported by supplied audit, not independently rerun in this pack.
- **New repo code/skills:** NOT IMPLEMENTED.
- **SAS semantic accuracy, Spark/Ray/Dask speedups, production parity:** NOT_RUN.
- **Human approval:** NOT GRANTED.
