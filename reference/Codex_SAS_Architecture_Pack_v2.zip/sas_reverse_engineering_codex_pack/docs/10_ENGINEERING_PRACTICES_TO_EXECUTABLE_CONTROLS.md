# 10 — Jim Thompson guidance translated into enforceable engineering practices

**Source:** user-provided `references/Jim Thompson Best Practices_ A Deep Learning Guide.md` (listed author: Manus AI), with primary reference [coding-assistant-practices](https://github.com/jimthompson5802/coding-assistant-practices). These are design adaptations, not proof of Copilot product capabilities. Verify model choices and reporting in the actual environment.

| Guidance | New-repo implementation | How to demonstrate / evaluate |
|---|---|---|
| Right capability for task | Route inventory/schema checks to deterministic code; use reasoning agents for ambiguous semantics; model choice configurable, never assumed available | Track per-task success, retries, latency and usage when observable; compare against baseline |
| Focused progressive context | Evidence retrieval by operation ID, module, dependency neighborhood and cited log span; expand only for a named question | Log which files/spans were loaded; negative test for hidden dependency outside initial neighborhood |
| Proportional planning | Lightweight plan for single operation, phased plan for cross-module redesign | Require acceptance criteria and risk-specific checks; reject giant unspecific plans |
| Open exploration then closed verification | Separate `propose-adrs` from `verify-claims` and `compare-adrs`; independent verifier never edits claims | Show valid citation supporting false inference rejected before approval |
| Bounded repair | One failure hypothesis and owning layer per attempt; preserve append-only evidence; stop at configured limits | Deliberately repeat same failure and show BLOCKED without infinite retries |
| Selective subagents | Parallelize independent read-only module investigations only when cost/coordination worthwhile; one reconciler owns global graph | Compare parallel agent throughput **and total usage** against serial baseline; catch contradictory graphs |
| Durable checkpoints | Seal source hashes, skill/evaluator versions, decisions, open questions and stage results | Resume from checkpoint; change source hash and demonstrate invalidation |
| Caching awareness | Stable reusable instructions; do not make cache-hit percentage an acceptance target | Report observed usage only if provider supplies authoritative data |
| Human ownership | All generated PRDs/ADRs/configs remain CANDIDATE; downstream human approves | Test that no skill can write APPROVED or bypass the downstream gate |

## Agent execution contract

Each skill must define trigger, allowed input scope, output path, one-step stop, verification command, forbidden mutations, missing-evidence behavior and explicit `does_not_prove`. Every agent call returns a small structured stage result with artifact hashes and next action. Use source snapshots, not chat history, as durable truth. Agent narration is never a gate result.

## Model and cost experiments

A/B-test an appropriately capable baseline against the proposed routing on identical withheld fixtures. Report accuracy, critical false approvals, recall, total elapsed time, retries, and provider-observed usage (when available). Avoid claims about enterprise billing from local token logs. More agents may decrease latency while increasing total consumption. Keep a record of environmental constraints and versions.

## Proof-of-practice showcase

Demo 1: scoped retrieval versus loading every log; verify same dependency recall and lower measured context/latency where observable. Demo 2: adversarial incorrect ADR; independent closed-loop verifier blocks it. Demo 3: missing evidence; stop with UNVERIFIABLE rather than inventing. Demo 4: changed source; stale checkpoint and ADR invalidate. Demo 5: selective subagent experiment with explicit cost/quality results. Mark any unrun demo NOT_RUN.
