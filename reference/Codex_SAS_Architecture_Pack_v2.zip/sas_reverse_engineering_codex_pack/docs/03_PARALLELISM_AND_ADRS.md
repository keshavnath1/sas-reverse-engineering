# 03 — Computation Parallelism, HLD/LLD and ADR Portfolio (Normative)

## Central question

For each pair of sequential SAS operations, **what precisely prevents safe concurrent execution?** A sequential log is evidence of *observed* order, not evidence of a required dependency. Build a DAG from source reads/writes, column lineage, macro/state effects, sort/BY boundaries, external effects, and run-linked log observations. Record both evidence for and evidence against each proposed edge removal.

## Eagle-eye analysis

1. Parse scope inventory and correlate programs, includes, macro invocations, log/LST execution steps, dataset/column producers/consumers, counts, elapsed/CPU and warnings. Preserve ambiguous source/log associations.
2. Build source operation DAG with edge types: `DATA`, `STATE`, `ORDER`, `SIDE_EFFECT`, `UNKNOWN`; separately annotate `RESOURCE` contention.
3. Identify critical path and independent antichains using observed durations **only where timestamps, run identity and comparable timings are trustworthy**. Critical path is a theoretical lower bound with unlimited resources, not a speed guarantee.
4. Identify repeated scans, redundant materialization, joins, sort/shuffle boundaries, repeated feature derivation, training repetitions, and possible fusion/shared preparation.
5. For each opportunity, specify preconditions, invariants, counterexamples, runtime resource costs, confidence and tests. Unknown macro expansion or side effects block a proof of independence.
6. Check at program, module, pipeline, stage, partition, column/expression, algorithm, feature engineering and training level.

## Parallelism blockers and allowed transformations

| Blocker | Evidence to collect | Candidate remedy (requires proof) |
|---|---|---|
| True producer-consumer edge | SAS SET/MERGE/SQL inputs, log run link | Retain edge; parallelize independent upstream branches |
| RETAIN/LAG/FIRST./LAST. or BY order | Source span, sort keys, reset semantics | Group-key partition with order-preserving within-group computation |
| Macro/global state | Expansion/call graph, SYMPUT/GET | Isolate contexts or serialize |
| Shared file/DB output | Write paths, transaction semantics | Unique outputs, coordinated commit, or serialization |
| Global aggregation/sort | GROUP BY/order and numerical rules | Local partial + deterministic final reduction if equivalent |
| Model training stochasticity | Seeds, sampling, solver/convergence, split definitions | Parallel trials/folds if independent; separately approve statistical equivalence for changed training |
| Shared expensive preparation | Repeated input scans and identical transformations | Reuse/fuse once if filtering and null semantics match |
| Memory/IO contention | Log/runtime measurements | Limit concurrency or prefer fusion; benchmark |
| Missing evidence | unresolved include/format/unknown consumer | BLOCK optimization until resolved |

## Mandatory ADR format (each viable candidate)

1. Identity, module(s), source manifest and source-record hash, candidate runtime, status DRAFT, explicit decision scope.
2. **As-is HLD:** SAS pipeline and module boundaries; log-observed order, datasets, external systems; Mermaid with cited operation IDs.
3. **As-is LLD:** operation DAG, input/output schema, state and ordering semantics, counts and run-specific timings; source locators.
4. **To-be HLD:** proposed module orchestration, shared data prep, concurrent stages, runtime boundaries, data movement, failure isolation, future module integration; Mermaid.
5. **To-be LLD:** transformations/fusions, task graph, partition keys, join strategy, shuffle/barriers, cache/materialization, numerical rules, state resets, training parallelism, memory/CPU sizing assumptions; Mermaid.
6. Explicit **difference table**: each source operation → target computation(s), removed/fused/reordered steps, unchanged business invariant, proof obligation and rollback.
7. Source-backed assumptions and negative evidence. Claim classification and verification statuses separate from benchmark execution status.
8. Alternatives and explicit exclusions. Compare Spark, Ray, Dask and native Python/NumPy; hybrid only with quantified interface/data-transfer risk.
9. Tradeoffs: correctness risk, end-to-end latency, throughput, p95, CPU-hours, peak memory, shuffle/network, developer/operational complexity, cloud cost, reproducibility, scale (data and module count), reversibility.
10. Baseline and benchmark protocol: same workload, input hash, hardware/resources, warm/cold cache, repeat counts, commit/runtime versions, cluster image/pod template, I/O included, confidence/variance; never fabricate numbers.
11. Required correctness checks: keys, row coverage, numerical tolerance, missing values, ordering/state, duplicate/missing keys, partition-sensitive behavior, scenario-specific parameters and coefficients.
12. Dependencies on other ADRs, effect of 5/10 more modules, integration and rollback triggers.
13. Verification report IDs, unresolved questions, independent reviewer and downstream human selection placeholder.

## Runtime-specific LLD obligations

- **Spark:** relational plan, Catalyst/native expression feasibility, partitioning, joins/shuffles, skew, spill, broadcast conditions, adaptive planning assumptions, executor/pod template/image versions, Spark job concurrency vs scheduler/resource limits, Python UDF overhead. Kubernetes reuse is a constraint, **not** proof Spark wins.
- **Ray:** remote task/actor DAG, dependency and object-store ownership, object transfers, scheduling/placement, task overhead, fault/retry semantics, data integration.
- **Dask:** collection type, lazy graph, scheduler/task granularity, partitioning, shuffles, serialization, memory spilling, cluster resources.
- **Native Python/NumPy:** vectorization, memory layout, GIL/process overhead, small-workload latency, numeric dtype/rounding, integration. NumPy inside a Spark executor may be useful in bounded vectorized kernels but can add serialization and per-worker memory; evaluate native Spark expressions first where suitable.
- **Hybrid:** quantify boundaries, serialization, ownership, orchestration and operational costs; don't assume 'best of all' is best overall.

## Distinguish independent trials from single-model training

Feature columns may be independent yet require a join/reconciliation before training. Cross-validation folds, scenarios and hyperparameter trials can often be scheduled independently if data leakage and random-state isolation are controlled. A single distributed optimizer may change summation order, convergence and learned coefficients; require separate behavior decision and statistical equivalence contract if exact SAS output tie-out is impossible.

## Illustrative Mermaid (not real SAS evidence)

```mermaid
flowchart LR
 X[Read inputs] --> A[Feature A]
 X --> B[Feature B]
 A --> J[Join keyed features]
 B --> J
 J --> T[Train model]
```

As-is sequential log may show `X → A → B → J → T`. Proposed parallel feature A/B is valid only after proving no A↔B state/data dependency and confirming compatible keys, sorting, null handling and resource capacity. **Do not use this illustration as an accepted dependency finding.**

## Comparison and selection

Keep one **behavioral tie-out target** across all candidates; do not permit each runtime to select convenient keys or tolerances. Use hard feasibility gates first (evidence, correctness preconditions, security, platform policy), then a transparent weighted decision matrix with **human-approved weights**. Missing benchmark => `NOT_RUN`, not a fabricated score. ADR selection occurs in Agent-mastery after independent reconciliation and human approval, not in the upstream repo.
