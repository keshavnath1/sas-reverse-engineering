#!/usr/bin/env python3
"""Structural checks for the documentation pack; NOT SAS or runtime validation."""
from pathlib import Path
import json, re, hashlib, sys
root=Path(__file__).resolve().parents[1]
errors=[]; results={}
files=[p for p in root.rglob('*') if p.is_file() and p.name not in ('MANIFEST.sha256','VERIFICATION_REPORT.md') and '__pycache__' not in p.parts]
required=['README.md']+[f'docs/{i:02d}_{n}.md' for i,n in enumerate(['PRODUCT_AND_SCOPE','ARCHITECTURE_AND_WORKFLOW','PARALLELISM_AND_ADRS','EVIDENCE_AND_EVALS','HANDOFF_AND_CONFIG','CODEX_BUILD_PLAN','REFERENCES_AND_PROVENANCE','DEMONSTRATION','REA_CASE_STUDIES_AND_IMPLEMENTATION_LESSONS','ENGINEERING_PRACTICES_TO_EXECUTABLE_CONTROLS','REPOSITORY_AUDIT_TO_IMPLEMENTATION_TRACEABILITY','FINAL_ONE_SHOT_CHECKLIST'],1)]
for r in required:
 if not (root/r).exists(): errors.append(f'Missing {r}')
results['required_documents']=len(required)
for p in root.rglob('*.json'):
 try: json.loads(p.read_text())
 except Exception as e: errors.append(f'Invalid JSON {p.relative_to(root)}: {e}')
results['json_files']=len(list(root.rglob('*.json')))
try:
 import jsonschema
 for p in (root/'contracts').glob('*.schema.json'):
  jsonschema.Draft202012Validator.check_schema(json.loads(p.read_text()))
 results['schema_validation']='PASS via jsonschema'
except ImportError: results['schema_validation']='NOT_RUN: jsonschema unavailable'
except Exception as e: errors.append(f'Schema validation error: {e}')
for p in root.rglob('*.md'):
 s=p.read_text(); fences=sum(bool(re.match(r'^\s*```',l)) for l in s.splitlines())
 if fences%2: errors.append(f'Unbalanced fences {p.relative_to(root)}')
 for link in re.findall(r'\[[^\]]+\]\(([^)]+)\)',s):
  if link.startswith(('http://','https://','#','mailto:')): continue
  if not (p.parent/link.split('#')[0]).exists(): errors.append(f'Broken relative link in {p.relative_to(root)}: {link}')
results['markdown_files']=len(list(root.rglob('*.md')))
for token in ['OBSERVATION','INFERENCE','ASSUMPTION','HYPOTHESIS','MEASUREMENT','VERIFIED','PARTIAL','UNSUPPORTED','CONTRADICTED','UNVERIFIABLE','NOT_RUN','BLOCKED']:
 if token not in (root/'docs/02_ARCHITECTURE_AND_WORKFLOW.md').read_text(): errors.append('Missing status '+token)
for token in ['Spark','Ray','Dask','NumPy','HLD','LLD']:
 if token not in (root/'docs/03_PARALLELISM_AND_ADRS.md').read_text(): errors.append('Missing architecture '+token)
manifest='\n'.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root).as_posix()}' for p in sorted(files))+'\n'
(root/'verification/MANIFEST.sha256').write_text(manifest)
results['files_hashed']=len(files)
results['errors']=errors
print(json.dumps(results,indent=2))
sys.exit(1 if errors else 0)
